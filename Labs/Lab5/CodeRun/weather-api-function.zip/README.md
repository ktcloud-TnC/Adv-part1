# Python Examples

이 문서는 Python를 이용한 함수 생성에 대한 이해를 돕기 위한 문서입니다. 

- `hello.py` pyyaml 라이브러리를 사용하는 간단한 함수 입니다.
- `requirements.txt` 는 함수에서 사용되는 라이브러리가 포함된 파일로 빌드 과정에서 사용됩니다.
