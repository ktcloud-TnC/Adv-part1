import redis
import json
from datetime import timedelta
import requests

openweathermap_api_key = 'b4616a64063053291a8bdac9a8a6b3e8'
openweathermap_url = 'http://api.openweathermap.org/data/2.5/weather'
redis_client = redis.StrictRedis(host='redis.ns99', port=6379, db=0, decode_responses=True)

cities = {
    "서울": {"lat": 37.5665, "lon": 126.9780},
    "인천": {"lat": 37.4563, "lon": 126.7052},
    "대전": {"lat": 36.3504, "lon": 127.3845},
    "대구": {"lat": 35.8722, "lon": 128.6025},
    "부산": {"lat": 35.1796, "lon": 129.0756},
    "광주": {"lat": 35.1595, "lon": 126.8526},
    "전주": {"lat": 35.8242, "lon": 127.1470},
    "제주": {"lat": 33.4996, "lon": 126.5312},
    "춘천": {"lat": 37.8813, "lon": 127.7298},
    "울릉도": {"lat": 37.4858, "lon": 130.9057}
}

def cache_weather(city, weather_data):
    redis_client.setex(city, timedelta(hours=12), json.dumps(weather_data))

def forecast(lat, lon):
    try:
        params = {
            'lat': lat,
            'lon': lon,
            'appid': openweathermap_api_key,
            'units': 'metric',
            'lang': 'kr'
        }
        res = requests.get(openweathermap_url, params=params)
        res.raise_for_status()
        json_data = res.json()

        weather_data = {
            'tmp': json_data['main']['temp'],
            'hum': json_data['main']['humidity'],
            'sky': json_data['weather'][0]['main'],
            'sky2': json_data['weather'][0]['description']
        }
        return weather_data
    except Exception as e:
        print(f"Error fetching weather data: {e}")
        return None

def update_weather_cache():
    for city, coords in cities.items():
        lat, lon = coords['lat'], coords['lon']
        weather_data = forecast(lat, lon)
        if weather_data:
            cache_weather(city, weather_data)
    print("Weather cache updated.")

if __name__ == '__main__':
    update_weather_cache()


